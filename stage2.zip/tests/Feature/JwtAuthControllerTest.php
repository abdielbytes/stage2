<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Tests\TestCase;
use Tymon\JWTAuth\Facades\JWTAuth;
use Carbon\Carbon;
class JwtAuthControllerTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Test token generation and expiration.
     *
     * @return void
     */
    public function testTokenGenerationAndExpiration()
    {
        $user = User::factory()->create();

        $token = JWTAuth::fromUser($user, ['expires' => now()->addHours(1)]);
        $this->assertNotNull($token);

        $tokenInstance = JWTAuth::getPayload($token);
        $expiresAt = Carbon::parse($tokenInstance['exp']);
        Log::info('Hii' . $expiresAt);
        $this->assertLessThanOrEqual(now()->addHours(2), $expiresAt);

        Log::info('Generated Token: ' . $token);
    }

    /**
     * Test organization access control.
     *
     * @return void
     */
    public function testOrganizationAccessControl()
    {
        $user1 = User::factory()->create();
        $user2 = User::factory()->create();

        $organization = $user1->organisations()->create([
            'orgId' => (string)Str::uuid(),
            'name' => "User1's Organisation",
            'description' => 'An organization',
        ]);

        $this->actingAs($user2);

        $response = $this->getJson('/api/organisations/' . $organization->orgId);

        $response->assertStatus(403); // Forbidden
    }
}
